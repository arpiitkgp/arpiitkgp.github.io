
    <ul>    
 <li class="namee">	<a id="proff" href="http://www.iitkgp.ac.in/fac-profiles/showprofile.php?empcode=SbmUQ&depts_name=AR">Haimanti Banerji	</a></li>	<li class="position">Assistant Professor	</li>	<li class="emaill">	haimanti @ arp.iitkgp.ernet.in	</li>	<hr class="facc">
<li class="namee">	<a id="proff" href="http://www.iitkgp.ac.in/fac-profiles/showprofile.php?empcode=ZVmWZ&depts_name=AR">Uttam Kumar Banerjee</a>	</li>	<li class="position">Professor	</li>	<li class="emaill">	ukb @ arp.iitkgp.ernet.in	</li>	<hr class="facc">
<li class="namee">	<a id="proff" href="http://www.iitkgp.ac.in/fac-profiles/showprofile.php?empcode=ZYmdT&depts_name=AR"> Jaydip Barman</a>	</li>	<li class="position">Professor	</li>	<li class="emaill">	jbarman @ arp.iitkgp.ernet.in	</li>	<hr class="facc">
<li class="namee">		<a id="proff" href="http://www.iitkgp.ac.in/fac-profiles/showprofile.php?empcode=ZVmWX&depts_name=AR">Sanghamitra Basu</a></li>	<li class="position">Associate Professor	</li>	<li class="emaill">	sbasu @ arp.iitkgp.ernet.in	</li>	<hr class="facc">
<li class="namee">	 <a id="proff" href="http://www.iitkgp.ac.in/fac-profiles/showprofile.php?empcode=SSmUW&depts_name=AR">Shankha Pratim Bhattacharya	 </a></li>	<li class="position">Assistant Professor	</li>	<li class="emaill">	spb @ arp.iitkgp.ernet.in	</li>	<hr class="facc">
<li class="namee">	<a id="proff" href="http://www.iitkgp.ac.in/fac-profiles/showprofile.php?empcode=zShdV&depts_name=AR">Banhi Chakraborty </a>	</li>	<li class="position">Assistant Professor	</li>	<li class="emaill">	banhi @ arp.iitkgp.ernet.in	</li>	<hr class="facc">
<li class="namee">	 <a id="proff" href="http://www.iitkgp.ac.in/fac-profiles/showprofile.php?empcode=ZZmWT&depts_name=AR">Subrata Chattopadhyay</a>	</li>	<li class="position">Professor	</li>	<li class="emaill">	schat @ arp.iitkgp.ernet.in	</li>	<hr class="facc">
<li class="namee">	 <a id="proff" href="http://www.iitkgp.ac.in/fac-profiles/showprofile.php?empcode=2bgbQ&depts_name=AR">Arup Das</a>	</li>	<li class="position">Assistant Professor	</li>	<li class="emaill">	arup.das @ arp.iitkgp.ernet.in	</li>	<hr class="facc">
<li class="namee">	<a id="proff" href="http://www.iitkgp.ac.in/fac-profiles/showprofile.php?empcode=SbmdT&depts_name=AR">Sutapa Das</a>	</li> 	<li class="position">Assistant Professor	</li>	<li class="emaill">	sutapa @ arp.iitkgp.ernet.in	</li>	<hr class="facc">
<li class="namee">		<a id="proff" href="http://www.iitkgp.ac.in/fac-profiles/showprofile.php?empcode=bamdT&depts_name=AR">Abraham George</a></li>	<li class="position">Associate Professor	</li>	<li class="emaill">	abraham @ arp.iitkgp.ernet.in	</li>	<hr class="facc">
<li class="namee">	<a id="proff" href="http://www.iitkgp.ac.in/fac-profiles/showprofile.php?empcode=2bfZQ&depts_name=AR">M Ghosh	</a></li>	<li class="position">Assistant Professor	</li>	<li class="emaill">	mg @ arp.iitkgp.ernet.in	</li>	<hr class="facc">
<li class="namee">		<a id="proff" href="http://www.iitkgp.ac.in/fac-profiles/showprofile.php?empcode=SUmVU&depts_name=AR">Sumana Gupta</a></li>	<li class="position">Assistant Professor	</li>	<li class="emaill">	sumana @ arp.iitkgp.ernet.in	</li>	<hr class="facc">
<li class="namee">	<a id="proff" href="http://www.iitkgp.ac.in/fac-profiles/showprofile.php?empcode=aZmdX&depts_name=AR">Tapan Kumar Majumdar	</a></li>	<li class="position">Assistant Professor	</li>	<li class="emaill">	tkm @ arp.iitkgp.ernet.in	</li>	<hr class="facc">
<li class="namee">		<a id="proff" href="http://www.iitkgp.ac.in/fac-profiles/showprofile.php?empcode=bVmaS&depts_name=AR">Tarak Nath Mazumder</a></li>	<li class="position">Associate Professor	</li>	<li class="emaill">		</li>	<hr class="facc">
<li class="namee">		<a id="proff" href="http://www.iitkgp.ac.in/fac-profiles/showprofile.php?empcode=bZmWT&depts_name=AR">Debapratim Pandit</a></li>	<li class="position">Associate Professor	</li>	<li class="emaill">	debapratim @ arp.iitkgp.ernet.in	</li>	<hr class="facc">
<li class="namee">		<a id="proff" href="http://www.iitkgp.ac.in/fac-profiles/showprofile.php?empcode=bYmUR&depts_name=AR">Saikat Kumar Paul</a></li>	<li class="position">Assistant Professor	</li>	<li class="emaill">	skpaul @ arp.iitkgp.ernet.in	</li>	<hr class="facc">
<li class="namee">	<a id="proff" href="http://www.iitkgp.ac.in/fac-profiles/showprofile.php?empcode=aZmWU&depts_name=AR">Joy Sen	</a></li>	<li class="position">Professor	</li>	<li class="emaill">	joysen @ arp.iitkgp.ernet.in	</li>	<hr class="facc">
<li class="namee">	<a id="proff" href="http://www.iitkgp.ac.in/fac-profiles/showprofile.php?empcode=ZYmdW&depts_name=AR">Somnath Sen	</a></li>	<li class="position">Associate Professor	</li>	<li class="emaill">	snsen @ arp.iitkgp.ernet.in	</li>	<hr class="facc">

         </ul>



<style type="text/css">
#proff{color: black; font-weight: bold;}
.position{font-size: 13px;}
.emaill{font-size: 13px;line-height: 11px;}
</style>










             