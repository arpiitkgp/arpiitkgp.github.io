<?php


mysql_connect("localhost","root","");
mysql_select_db("arch");

$result2=mysql_query("SELECT * from staff")
  or die("fuck off".mysql_error());

   if(isset($_POST['delete'])){ 

$name=$_POST['varname'];
$year=$_POST['year'];
setcookie('var',$name,time() + (86400 * 7),"/");
setcookie('year',$year,time() + (86400 * 7),"/");
echo "<script> window.location='profiles.php' </script>";};

  
?>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>

        <div class="site-content">
            
  <h5><b>Staff list</b></h5><hr>
        <div id="content">
        <table class="table table-hover" width="70vmax"  align="center"> 
          <thead>
            <tr> <th valign="top" class="cx" >Name</th> 
            <th valign="top" class="cx" >Designation</th> 
            
            <th valign="top" class="cx">Phone Number</th>
          </tr> </thead><tbody>
          <?php 
$i=1;
  while($rower2= mysql_fetch_array($result2)) {

        echo "<tr><td class='bx'>" . $rower2["rollno"]."</td><td class='bx'><form method='POST'> <input type='hidden' name='year' value='" .$rower2["rollno"]. "'><input type='hidden' name='varname' value='" .$rower2["id"]. "'>" . $rower2["name"]. "</form></td><td class='bx' >"  . $rower2["email"]. " </td></tr> "; $i++;
        
    };?>      
          </tbody>
                    
        </table>  
        </div>  

            </div>
        
