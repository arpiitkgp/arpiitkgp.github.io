<?php


mysql_connect("localhost","root","");
mysql_select_db("arch");

$result2=mysql_query("SELECT * from five ")
  or die("OPPS".mysql_error());

   if(isset($_POST['delete'])){ 

$name=$_POST['varname'];
$year=$_POST['year'];
setcookie('var',$name,time() + (86400 * 7),"/");
setcookie('year',$year,time() + (86400 * 7),"/");
echo "<script> window.location='profiles.php' </script>";};

  
?>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>

        <div class="site-content">
            
        <h4 style="float:right; border-bottom: 7px solid black;"><b>VIZWAKRITS</b></h4><br><br><br><br>
        <div id="content">
       
          <ul>
          <?php 
$i=1;
  while($rower2= mysql_fetch_array($result2)) {

        echo "<li class='namee'>" . $rower2["name"]."</li><li class='position'>" . $rower2["rollno"]. "</li><li class='emaill' >"  . $rower2["email"]. " </li><hr class='rule'> "; $i++;
        
    };?>      
          </ul>
                    
        <style type="text/css">
        .namee{font-weight: bold;}
#proff{font-size: 18px;}
.position{font-size: 13px;}
.emaill{font-size: 13px;line-height: 11px;}
</style>
        </div>  

            </div>
        
