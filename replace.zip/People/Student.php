            <div id="main" style="padding=10px;" class="col m12 l9 s12">
                The Department of Architecture and Regional Department faculty represents a broad range of academic background as well as practice and research interests. Each member belongs to a discipline group according his or her expertise. Our Architecture family comprises of Faculty members, Undergaduate (UG) Student, Master of City Planning (MCP) Students, PHD Students, Staff members and other workers.
        </div>
