
            <div class="container">
				<h5><b>Alumni 2014</b></h5>
				<div id="content">
				<table class="table table-hover" width="50vmax"   align="center" > 
					<thead class="thead-inverse">
					<tr> 
						<th class="cx" >&nbsp;Batch</th> 
						<th class="cx" >Name</th> 
						<th class="cx" >Hall</th>
						<th class="cx">E-mail</th>
					</tr> </thead><tbody>
					<tr>
						<td class="bx">&nbsp;2009</td> 
										
				<td class="bx">ANKIT ITORIA</td> 
						<td class="bx">AZ&nbsp;</td> 
			
				<td class="bx"><a href="mailto:ankit.itoria@gmail.com">ankit.itoria@gmail.com</a></td> 
 
																</tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009</td> 
										
				<td class="bx">KRISHNANUNNI J.</td> 
						<td class="bx">AZ&nbsp;</td> 
				
				<td class="bx"><a href="mailto:krishnanunni.j.20@gmail.com">krishnanunni.j.20@gmail.com</a></td> 
 
	  </tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009</td> 
										
				<td class="bx">AKSHAY CHALIKWAR</td> 
						<td class="bx">AZ&nbsp;</td> 
				
				<td class="bx"><a href="mailto:aschalikwar@gmail.com">aschalikwar@gmail.com</a></td> 
 
	  </tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009	</td> 
									
				<td class="bx">SHUBHAM KHATTRI</td> 
						<td class="bx">AZ&nbsp;</td> 
				
				<td class="bx"><a href="mailto:iitkgpshubham.khatri@gmail.com">iitkgpshubham.khatri@gmail.com</a></td> 
 
	  </tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009</td> 
										
				<td class="bx">AKANKSHA AGRAWAL</td> 
						
				<td class="bx">SN</td> 
			 
				<td class="bx"><a href="mailto:akankshagrawalkgp@gmail.com">akankshagrawalkgp@gmail.com</a></td> 
 
	  </tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009	</td> 
									
				<td class="bx">SURAJ D. SHINDE</td> 
						<td class="bx">AZ&nbsp;</td> 
				 
				<td class="bx"><a href="mailto:surajdadasaheb123@gmail.com">surajdadasaheb123@gmail.com</a></td> 
 
	  </tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009	</td> 
									
				<td class="bx">KAPIL MANGTANI</td> 
						<td class="bx">AZ&nbsp;</td> 
			 
				<td class="bx"><a href="mailto:kapil.mangtani.mangtani@gmail.com">kapil.mangtani.mangtani@gmail.com</a></td> 
 
	  </tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009</td> 
										
				<td class="bx">SHREYAS MAHAJAN</td> 
						<td class="bx">AZ&nbsp;</td> 
				 
				<td class="bx"><a href="mailto:shreyasm.iitkgp@gmail.com">shreyasm.iitkgp@gmail.com</a></td> 
 
	  </tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009</td> 
										
				<td class="bx">PRAVEEN DAS</td> 
						<td class="bx">AZ&nbsp;&nbsp;</td> 
				
				<td class="bx"><a href="mailto:praveeniitkgp09@gmail.com">praveeniitkgp09@gmail.com</a></td> 
 
	  </tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009</td> 
										
				<td class="bx">NISHANT VATS</td> 
						<td class="bx">AZ&nbsp;</td> 
				 
				<td class="bx"><a href="mailto:nishantvats12@gmail.com">nishantvats12@gmail.com</a></td> 
 
	  </tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009</td> 
										
				<td class="bx">PRIYANKA RAJU</td> 
						
				<td class="bx">SN&nbsp;</td> 
				
				<td class="bx"><a href="mailto:priyankaraju.d@gmail.com">priyankaraju.d@gmail.com</a></td> 
 
	  </tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009</td> 
										
				<td class="bx">SHASHANK TIWARI</td> 
						<td class="bx">AZ&nbsp;</td> 
				 
				<td class="bx"><a href="mailto:tiwari.g16@gmail.com">tiwari.g16@gmail.com</a></td> 
 
	  </tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009	</td> 
									
				<td class="bx">ASHISH CHAWDA</td> 
						
				<td class="bx">RK</td> 
				 
				<td class="bx"><a href="mailto:ashishchawda156@gmail.com">ashishchawda156@gmail.com</a></td> 
 
	  </tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009	</td> 
									
				<td class="bx">ARCHIT LAHOTI</td> 
						<td class="bx">RK</td> 
				 
                    <td class="bx"><a href="mailto:archit163@gmail.com">archit163@gmail.com</a></td> 
 
	  </tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009	</td> 
									
				<td class="bx">ANKIT CHAUDHARY</td> 
						<td class="bx">RK</td> 
				
				<td class="bx"><a href="mailto:iitankitabhi@gmail.com">iitankitabhi@gmail.com</a></td> 
 
	  </tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009</td> 
										
				<td class="bx">VISHAL AGRAWAL</td> 
						<td class="bx">RK&nbsp;</td> 
				
				<td class="bx"><a href="mailto:vishalagarwaliitkgp@gmail.com">vishalagarwaliitkgp@gmail.com</a></td> 
 
	  </tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009	</td> 
									
				<td class="bx">AAKASH SAXENA</td> 
						<td class="bx">RK&nbsp;</td> 
				 
				<td class="bx"><a href="mailto:aakash179@gmail.com">aakash179@gmail.com</a></td> 
 
	  </tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009</td> 
										
				<td class="bx">SIRAM NEEHARIKA</td> 
						
				<td class="bx">SN</td> 
			
				<td class="bx"><a href="mailto:siramneeharika@gmail.com">siramneeharika@gmail.com</a></td> 
 
																</tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009	</td> 
									
				<td class="bx">RITESH JINDAL</td> 
						<td class="bx">RK</td> 
				
				<td class="bx"><a href="mailto:jindalritesh1026@gmail.com">jindalritesh1026@gmail.com</a></td> 
 
																</tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009</td> 
										
				<td class="bx">AAKASH KEDIA</td> 
						<td class="bx">RK</td> 
				
				<td class="bx"><a href="mailto:aakashkedia2009@gmail.com">aakashkedia2009@gmail.com</a></td> 
 
																</tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009	</td> 
									
				<td class="bx">RAJEEV SUDAKAR</td> 
						<td class="bx">RK</td> 
				
				<td class="bx"><a href="mailto:rajeevsudhakar@gmail.com">rajeevsudhakar@gmail.com</a></td> 
 
																</tr> 
 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009</td> 
										
				<td class="bx">YERRA LOKESHWARI RAMYA</td> 
						
				<td class="bx">SN</td> 
				
				<td class="bx"><a href="mailto:lokeswari.iit@gmail.com">lokeswari.iit@gmail.com</a></td> 
 
																</tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009	</td> 
									
				<td class="bx">NANDITA UPPADA</td> 
						<td class="bx">SN&nbsp;</td> 
				 
				<td class="bx"><a href="mailto:nanditha.uppada@gmail.com">nanditha.uppada@gmail.com</a></td> 
 
																</tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009</td> 
										
				<td class="bx">JAYAN PRAJAPATI</td> 
						<td class="bx">RK</td> 
				
				<td class="bx"><a href="mailto:jayannprajapati@gmail.com">jayannprajapati@gmail.com</a></td> 
 
																</tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009</td> 
										
				<td class="bx">RAGHUKULESH</td> 
						<td class="bx">RK&nbsp;</td> 
			
				<td class="bx"><a href="mailto:raghukulesh@gmail.com">raghukulesh@gmail.com</a></td> 
 
																</tr> 
 
							<tr> 
				
					
					
				<td class="bx">&nbsp;2009</td> 
										
				<td class="bx">KRITIKA PRASAD</td> 
						
				<td class="bx">SN</td> 
			
				<td class="bx"><a href="mailto:"></a></td> 
                                        
                                                                </tr> 
                <tr> 
				
					
					
				<td class="bx">&nbsp;2009</td> 
										
				<td class="bx">B. SAI CHARAN</td> 
						
				<td class="bx">RP</td> 
			
				<td class="bx"><a href="mailto:charan.charan14@gmail.com">charan.charan14@gmail.com</a></td> 
                                        
      </tr> 
                                                                
               <tr> 
				
					
					
				<td class="bx">&nbsp;2009</td> 
										
				<td class="bx">AJIT ANAND TIRKEY</td> 
						
				<td class="bx">PH</td> 
			
				<td class="bx"><a href="mailto:ajitanandtirkey608@gmail.com">ajitanandtirkey608@gmail.com</a></td> 
                                        
      </tr> <tr> 
				
					
					
				<td class="bx">&nbsp;2009	</td> 
									
				<td class="bx">PRIYA MISHRA</td> 
						
				<td class="bx">SN</td> 
			
				<td class="bx"><a href="mailto:priyamishraiit@gmail.com">priyamishraiit@gmail.com</a></td> 
                                        
                                                                </tr> <tr> 
				
					
					
				<td class="bx">&nbsp;2009</td> 
										
				<td class="bx">TANAY NIGAM</td> 
						
				<td class="bx">RK</td> 
			
				<td class="bx"><a href="mailto:nigam.tanay@gmail.com">nigam.tanay@gmail.com</a></td> 
                                        
                                                                </tr> 
                                                                <tr> 
				
					
					
				<td class="bx">&nbsp;2009</td> 
										
				<td class="bx">SONAL BHADAURIA</td> 
						
				<td class="bx">SN</td> 
			
				<td class="bx"><a href="mailto:sonalbhadauria.iitkgp@gmail.com">sonalbhadauria.iitkgp@gmail.com</a></td>  
					</tr> </tbody>
				</table>  
				</div>             
            </div>
        